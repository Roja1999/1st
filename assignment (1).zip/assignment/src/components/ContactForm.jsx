import React, { useState, useEffect } from 'react';

const ContactForm = ({ addContact, updateContact, currentContact, setCurrentContact }) => {
    const [form, setForm] = useState({ name: '', email: '', contact: '' });

    useEffect(() => {
        if (currentContact) {
            setForm(currentContact);
        } else {
            setForm({ name: '', email: '', contact: '' });
        }
    }, [currentContact]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setForm({ ...form, [name]: value });
    };

    const handleAddUpdate = () => {
        if (currentContact) {
            updateContact({ id: currentContact.id, ...form });
        } else {
            addContact(form);
        }
        setForm({ name: '', email: '', contact: '' });
        setCurrentContact(null);
    };

    return (
        <div className="contact-form">
            <div className="form-group">
                <label>
                    Name
                    <input type="text" name="name" value={form.name} onChange={handleInputChange} />
                </label>
            </div>
            <div className="form-group">
                <label>
                    Email
                    <input type="text" name="email" value={form.email} onChange={handleInputChange} />
                </label>
            </div>
            <div className="form-group">
                <label>
                    Contact
                    <input type="text" name="contact" value={form.contact} onChange={handleInputChange} />
                </label>
            </div>
            <button className="btn-add-update" onClick={handleAddUpdate}>
                {currentContact ? 'Update' : 'Add'}
            </button>
        </div>
    );
};

export default ContactForm;